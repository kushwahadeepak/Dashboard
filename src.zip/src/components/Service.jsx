import React from 'react'
import Navbar from './Navbar'

const Service = () => {
  return (
    <>
      <Navbar/>
      <h1>Service</h1>
    </>
  )
}

export default Service
