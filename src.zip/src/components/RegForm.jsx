import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar'

const RegForm = () => {
  const [name, setName]=useState();
  const [email, setEmail]=useState();
  const [password, setPassword]=useState();

  const  Navigat= useNavigate()

async function registration(){
      let item={name, email,password}
      let result = await fetch("http://142.39.221.114/auth/register",{
        method: 'POST',
        headers:{
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body:JSON.stringify(item)
      });
      result =await result.json();
      console.log("result", result)
      localStorage.setItem("user-info", JSON.stringify(result));
      Navigat("/")
  }
  return (
    <>
     <Navbar/> 
   <div className='col-sm-6 offset-sm-3'>
    <h2 className='text-center my-3 '>Registration</h2>
     <input type='text' className="form-control" value={name} placeholder="Name" onChange={(e)=>setName(e.target.value)}/>
     <br/>
     <input type='email' className="form-control" value={email} placeholder="Email" onChange={(e)=>setEmail(e.target.value)}/>
     <br/>
     <input type='password' className="form-control" value={password} placeholder="Password" onChange={(e)=>setPassword(e.target.value)}/>
     <br/>
     <button type='button' className='btn btn-primary' onClick={registration}>Registor</button>
   </div>
    </>
  )
}

export default RegForm
