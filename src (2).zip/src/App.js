import {BrowserRouter, Route, Routes} from 'react-router-dom'
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import Home from './Components/Home';
import LogAuth from './Components/LogAuth';
import Regauth from './Components/Regauth';
import Service from './Components/Service';
import { ToastContainer } from 'react-toastify';
function App() {
  return (
   <>
   <ToastContainer theme= 'colored'> </ToastContainer>
    <BrowserRouter>
    <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path='service' element={<Service/>}/>
    <Route path ="logauth" element={<LogAuth/>}/>
    <Route path = "reg" element={<Regauth/>}/>
    </Routes>
    </BrowserRouter>
   </>
  );
}

export default App;
