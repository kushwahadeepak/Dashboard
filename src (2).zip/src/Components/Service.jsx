import React,{useEffect} from 'react'
import Navbar from './Navbar'
import { useNavigate } from 'react-router-dom';
const Service = () => {
  const navigate = useNavigate();
  useEffect(()=>{
  let name =sessionStorage.getItem('name');
  if(name === "" || name === null){
    navigate('/logauth');
  }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
   <>
   <Navbar/>
   <h1>Service</h1>
   </>
  )
}

export default Service